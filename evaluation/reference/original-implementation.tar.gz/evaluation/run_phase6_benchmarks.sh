#!/usr/bin/env bash
# Reproducible Phase 6 benchmark for the existing baseline and folded modes.
# Compilation is completed before measurement and is not included in any sample.
set -euo pipefail

runs="${1:-7}"
warmup_iterations="${VERIFY_WARMUP_ITERATIONS:-20}"
timed_iterations="${VERIFY_TIMED_ITERATIONS:-200}"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
project_dir="$(cd "${script_dir}/.." && pwd)"
output_dir="${BENCHMARK_OUTPUT_DIR:-${project_dir}/evaluation/output/phase6-$(date -u +%Y%m%dT%H%M%SZ)}"
witness_path="${WITNESS_PATH:-${project_dir}/issuer/output/witness_0.json}"

if [[ -z "${ROOT_LIMB0:-}" || -z "${ROOT_LIMB1:-}" ]]; then
    echo "Set ROOT_LIMB0 and ROOT_LIMB1 from npm run fetch:root before benchmarking." >&2
    exit 2
fi

if [[ ! -f "${witness_path}" ]]; then
    echo "Witness file not found: ${witness_path}" >&2
    exit 2
fi

if [[ ! -x /usr/bin/time ]]; then
    echo "/usr/bin/time is required for whole-process peak RSS measurement." >&2
    exit 2
fi

mkdir -p "${output_dir}"
cd "${project_dir}"
cargo build --release -p prover-verifier

source_revision="$(git rev-parse --short HEAD)"
if ! git diff --quiet || [[ -n "$(git ls-files --others --exclude-standard)" ]]; then
    source_revision="${source_revision}-dirty"
fi

python3 - "${output_dir}/metadata.json" <<PY
import json
from datetime import datetime, timezone
json.dump({
    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    "source_revision": "${source_revision}",
    "runs_per_mode": int("${runs}"),
    "verification_warmup_iterations": int("${warmup_iterations}"),
    "verification_timed_iterations": int("${timed_iterations}"),
    "witness_path": "${witness_path}",
    "root_limb0": "${ROOT_LIMB0}",
    "root_limb1": "${ROOT_LIMB1}",
}, open("${output_dir}/metadata.json", "w"), indent=2)
PY

: > "${output_dir}/results.jsonl"
for run in $(seq 1 "${runs}"); do
    for mode in baseline folded; do
        json_path="${output_dir}/run-${run}-${mode}.json"
        time_path="${output_dir}/run-${run}-${mode}.time"
        VERIFY_WARMUP_ITERATIONS="${warmup_iterations}" \
        VERIFY_TIMED_ITERATIONS="${timed_iterations}" \
        /usr/bin/time -v -o "${time_path}" \
            "${project_dir}/target/release/prover-verifier" \
            --witness "${witness_path}" --mode "${mode}" \
            "${ROOT_LIMB0}" "${ROOT_LIMB1}" > "${json_path}"

        rss_bytes="$(( $(sed -n 's/.*Maximum resident set size (kbytes): //p' "${time_path}") * 1024 ))"
        python3 - "${json_path}" "${run}" "${rss_bytes}" "${source_revision}" <<'PY' >> "${output_dir}/results.jsonl"
import json
import sys
from datetime import datetime, timezone

record = json.load(open(sys.argv[1]))
record.update({
    "run_id": int(sys.argv[2]),
    "whole_process_peak_rss_bytes": int(sys.argv[3]),
    "source_revision": sys.argv[4],
    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
})
print(json.dumps(record, sort_keys=True))
PY
    done
done

python3 - "${output_dir}/results.jsonl" "${output_dir}/results.csv" <<'PY'
import csv
import json
import sys

records = [json.loads(line) for line in open(sys.argv[1]) if line.strip()]
fields = sorted({field for record in records for field in record})
with open(sys.argv[2], "w", newline="") as output:
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    writer.writerows(records)
PY

echo "Benchmark records: ${output_dir}/results.jsonl"
echo "CSV records:       ${output_dir}/results.csv"
