//! Phase 4 issuer: generates a credential batch, the Rescue Merkle root, and one private witness.

use std::{env, fs, path::PathBuf};

use merkle_core::{root_from_path, Hash, Rescue128};
use rand::{rngs::OsRng, RngCore};
use serde::{Deserialize, Serialize};
use winterfell::{
    crypto::MerkleTree,
    math::{fields::f128::BaseElement, StarkField},
};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RootFile {
    pub root_limb0: String,
    pub root_limb1: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PathNode {
    pub limb0: String,
    pub limb1: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct WitnessFile {
    pub value_limb0: String,
    pub value_limb1: String,
    pub index: usize,
    pub path: Vec<PathNode>,
}

impl WitnessFile {
    pub fn value(&self) -> Result<[BaseElement; 2], String> {
        Ok([
            BaseElement::new(
                self.value_limb0
                    .parse::<u128>()
                    .map_err(|_| "invalid value_limb0")?,
            ),
            BaseElement::new(
                self.value_limb1
                    .parse::<u128>()
                    .map_err(|_| "invalid value_limb1")?,
            ),
        ])
    }

    pub fn path_hashes(&self) -> Result<Vec<Hash>, String> {
        self.path
            .iter()
            .map(|node| {
                Ok(Hash::new(
                    BaseElement::new(
                        node.limb0
                            .parse::<u128>()
                            .map_err(|_| "invalid path limb0")?,
                    ),
                    BaseElement::new(
                        node.limb1
                            .parse::<u128>()
                            .map_err(|_| "invalid path limb1")?,
                    ),
                ))
            })
            .collect()
    }
}

fn random_credential() -> [BaseElement; 2] {
    let mut rng = OsRng;
    [
        BaseElement::new(rng.next_u64() as u128),
        BaseElement::new(rng.next_u64() as u128),
    ]
}

pub fn issue(depth: usize, holder_index: usize) -> Result<(RootFile, WitnessFile), String> {
    let leaf_count = 1usize
        .checked_shl(depth as u32)
        .ok_or("depth is too large")?;
    if depth == 0 || holder_index >= leaf_count {
        return Err("depth must be positive and holder_index must be within the tree".into());
    }
    let credentials: Vec<[BaseElement; 2]> = (0..leaf_count).map(|_| random_credential()).collect();
    let leaves: Vec<Hash> = credentials
        .iter()
        .map(|value| Rescue128::digest(value))
        .collect();
    let tree = MerkleTree::<Rescue128>::new(leaves).map_err(|error| error.to_string())?;
    let (_, path) = tree
        .prove(holder_index)
        .map_err(|error| error.to_string())?;
    let root = tree.root().to_elements();
    let value = credentials[holder_index];
    let witness = WitnessFile {
        value_limb0: value[0].as_int().to_string(),
        value_limb1: value[1].as_int().to_string(),
        index: holder_index,
        path: path
            .iter()
            .map(|node| {
                let elements = node.to_elements();
                PathNode {
                    limb0: elements[0].as_int().to_string(),
                    limb1: elements[1].as_int().to_string(),
                }
            })
            .collect(),
    };
    debug_assert_eq!(
        root_from_path(value, &path, holder_index).to_elements(),
        root
    );
    Ok((
        RootFile {
            root_limb0: root[0].as_int().to_string(),
            root_limb1: root[1].as_int().to_string(),
        },
        witness,
    ))
}

fn output_directory() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("output")
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut arguments = env::args().skip(1);
    let depth: usize = arguments
        .next()
        .ok_or("usage: issuer <depth> <holder_index>")?
        .parse()?;
    let holder_index: usize = arguments
        .next()
        .ok_or("usage: issuer <depth> <holder_index>")?
        .parse()?;
    if arguments.next().is_some() {
        return Err("usage: issuer <depth> <holder_index>".into());
    }
    let (root, witness) =
        issue(depth, holder_index).map_err(|error| format!("issuer failed: {error}"))?;
    let output = output_directory();
    fs::create_dir_all(&output)?;
    fs::write(
        output.join("root.json"),
        serde_json::to_string_pretty(&root)?,
    )?;
    fs::write(
        output.join(format!("witness_{holder_index}.json")),
        serde_json::to_string_pretty(&witness)?,
    )?;
    println!("root_limb0: {}", root.root_limb0);
    println!("root_limb1: {}", root.root_limb1);
    println!("witness_path_length: {}", witness.path.len());
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn issued_witness_reconstructs_root() {
        let (root, witness) = issue(3, 5).unwrap();
        let reconstructed = root_from_path(
            witness.value().unwrap(),
            &witness.path_hashes().unwrap(),
            witness.index,
        );
        assert_eq!(
            reconstructed.to_elements()[0].as_int().to_string(),
            root.root_limb0
        );
        assert_eq!(
            reconstructed.to_elements()[1].as_int().to_string(),
            root.root_limb1
        );
        assert_eq!(witness.path.len(), 3);
    }
    #[test]
    fn witness_serialization_round_trip() {
        let (_, witness) = issue(3, 1).unwrap();
        let encoded = serde_json::to_string(&witness).unwrap();
        assert_eq!(
            serde_json::from_str::<WitnessFile>(&encoded).unwrap(),
            witness
        );
    }
    #[test]
    fn tampered_witness_does_not_reconstruct_root() {
        let (root, mut witness) = issue(3, 2).unwrap();
        witness.path[0].limb0 = "0".into();
        let reconstructed = root_from_path(
            witness.value().unwrap(),
            &witness.path_hashes().unwrap(),
            witness.index,
        );
        assert_ne!(
            reconstructed.to_elements()[0].as_int().to_string(),
            root.root_limb0
        );
    }
}
