const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

function uint128ToLittleEndianBytes(value) {
  let remaining = BigInt(value);
  if (remaining < 0n || remaining >= (1n << 128n)) {
    throw new Error("each root limb must be an unsigned 128-bit integer");
  }

  const bytes = Buffer.alloc(16);
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = Number(remaining & 0xffn);
    remaining >>= 8n;
  }
  return bytes;
}

async function main() {
  const { ROOT_LIMB0: limb0, ROOT_LIMB1: limb1 } = process.env;
  if (limb0 === undefined || limb1 === undefined) {
    throw new Error("set ROOT_LIMB0 and ROOT_LIMB1 to the decimal values from prover-verifier");
  }

  const deploymentPath = path.join(__dirname, "..", "deployment.json");
  const { address } = JSON.parse(fs.readFileSync(deploymentPath, "utf8"));
  const root = Buffer.concat([
    uint128ToLittleEndianBytes(limb0),
    uint128ToLittleEndianBytes(limb1),
  ]);
  const rootHex = "0x" + root.toString("hex");

  const registry = await hre.ethers.getContractAt("CredentialRegistry", address);
  const transaction = await registry.publishRoot(rootHex);
  const receipt = await transaction.wait();

  console.log("published_root:", rootHex);
  console.log("transaction_hash:", receipt.hash);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

