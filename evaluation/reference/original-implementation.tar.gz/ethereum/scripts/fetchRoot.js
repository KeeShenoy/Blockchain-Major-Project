const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

function littleEndianBytesToBigInt(bytes) {
  let value = 0n;
  for (let index = bytes.length - 1; index >= 0; index -= 1) {
    value = (value << 8n) | BigInt(bytes[index]);
  }
  return value;
}

async function main() {
  const deploymentPath = path.join(__dirname, "..", "deployment.json");
  const { address } = JSON.parse(fs.readFileSync(deploymentPath, "utf8"));

  const registry = await hre.ethers.getContractAt("CredentialRegistry", address);
  const rootHex = await registry.getRoot();
  const rootBytes = Buffer.from(rootHex.slice(2), "hex");

  if (rootBytes.length !== 32) {
    throw new Error("registry returned an invalid bytes32 root");
  }

  console.log("root_hex:", rootHex);
  console.log("root_limb0:", littleEndianBytesToBigInt(rootBytes.subarray(0, 16)).toString());
  console.log("root_limb1:", littleEndianBytesToBigInt(rootBytes.subarray(16, 32)).toString());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

