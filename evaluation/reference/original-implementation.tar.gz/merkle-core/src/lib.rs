//! Canonical Rescue128 Merkle primitives shared by the issuer and prover/verifier.

pub mod rescue;
mod utils;

use winterfell::math::fields::f128::BaseElement;

pub use rescue::{Hash, Rescue128};
pub use utils::{are_equal, is_binary, is_zero, not, EvaluationResult};

/// Reconstructs a Rescue Merkle root from a leaf value, authentication path, and index.
pub fn root_from_path(value: [BaseElement; 2], path: &[Hash], index: usize) -> Hash {
    let mut current = Rescue128::digest(&value);
    for (level, sibling) in path.iter().enumerate() {
        let current_elements = current.to_elements();
        let sibling_elements = sibling.to_elements();
        let elements = if ((index >> level) & 1) == 0 {
            [
                current_elements[0],
                current_elements[1],
                sibling_elements[0],
                sibling_elements[1],
            ]
        } else {
            [
                sibling_elements[0],
                sibling_elements[1],
                current_elements[0],
                current_elements[1],
            ]
        };
        current = Rescue128::digest(&elements);
    }
    current
}
