use core::ops::Range;

use winterfell::{
    math::{FieldElement, StarkField},
    Trace, TraceTable,
};

/// Returns zero only when a == b.
pub fn are_equal<E: FieldElement>(a: E, b: E) -> E {
    a - b
}

/// Returns zero only when a == zero.
pub fn is_zero<E: FieldElement>(a: E) -> E {
    a
}

/// Returns zero only when a is zero or one.
pub fn is_binary<E: FieldElement>(a: E) -> E {
    a * a - a
}

/// Returns one when a is zero and zero when a is one.
pub fn not<E: FieldElement>(a: E) -> E {
    E::ONE - a
}

pub trait EvaluationResult<E> {
    fn agg_constraint(&mut self, index: usize, flag: E, value: E);
}

impl<E: FieldElement> EvaluationResult<E> for [E] {
    fn agg_constraint(&mut self, index: usize, flag: E, value: E) {
        self[index] += flag * value;
    }
}

impl<E: FieldElement> EvaluationResult<E> for Vec<E> {
    fn agg_constraint(&mut self, index: usize, flag: E, value: E) {
        self[index] += flag * value;
    }
}

#[allow(dead_code)]
pub fn print_trace<E: StarkField>(
    trace: &TraceTable<E>,
    multiples_of: usize,
    offset: usize,
    range: Range<usize>,
) {
    let trace_width = trace.width();
    let mut state = vec![E::ZERO; trace_width];
    for i in 0..trace.length() {
        if !(i.wrapping_sub(offset)).is_multiple_of(multiples_of) {
            continue;
        }
        trace.read_row_into(i, &mut state);
        println!(
            "{}\t{:?}",
            i,
            state[range.clone()]
                .iter()
                .map(|value| value.as_int())
                .collect::<Vec<E::PositiveInteger>>()
        );
    }
}

#[allow(dead_code)]
pub fn print_trace_step<E: StarkField>(trace: &[Vec<E>], step: usize) {
    let mut state = vec![E::ZERO; trace.len()];
    for (column, value) in trace.iter().zip(state.iter_mut()) {
        *value = column[step];
    }
    println!(
        "{}\t{:?}",
        step,
        state
            .iter()
            .map(|value| value.as_int())
            .collect::<Vec<E::PositiveInteger>>()
    );
}
