//! Phase 2 baseline with Phase 3 Ethereum trust-anchor integration.
//!
//! The AIR, prover, and Rescue Merkle-path logic are unchanged. Phase 3 makes
//! the temporary test tree deterministic so the root published to Ethereum can
//! be reconstructed in a later process. Phase 4 replaces this stand-in with
//! actual issuer-supplied credentials and witnesses.

mod air;
mod prover;

use std::{
    fs::File,
    io::BufReader,
    marker::PhantomData,
    path::Path,
    time::{Duration, Instant},
};

use merkle_core::rescue::{
    Hash, Rescue128, CYCLE_LENGTH as HASH_CYCLE_LEN, NUM_ROUNDS as NUM_HASH_ROUNDS,
    STATE_WIDTH as HASH_STATE_WIDTH,
};
use merkle_core::root_from_path;
use serde::Deserialize;
use winterfell::{
    crypto::{hashers::Blake3_256, DefaultRandomCoin, ElementHasher, MerkleTree},
    math::{fields::f128::BaseElement, FieldElement, StarkField},
    BatchingMethod, FieldExtension, Proof, ProofOptions, Prover, VerifierError,
};

use air::{MerkleAir, PublicInputs};
use prover::MerkleProver;

const DEFAULT_TREE_DEPTH: usize = 7;
const DEFAULT_TREE_SEED: u64 = 42;
const TRACE_WIDTH: usize = 7;
const DEFAULT_VERIFY_WARMUP_ITERATIONS: usize = 10;
const DEFAULT_VERIFY_TIMED_ITERATIONS: usize = 100;
type StarkCommitmentHasher = Blake3_256<BaseElement>;

/// Returns the operating system's peak resident-set measurement for this proof
/// process. Linux reports `ru_maxrss` in KiB, hence the conversion to bytes.
#[cfg(target_os = "linux")]
fn peak_memory_bytes() -> Option<u64> {
    let mut usage = std::mem::MaybeUninit::<libc::rusage>::zeroed();
    let result = unsafe { libc::getrusage(libc::RUSAGE_SELF, usage.as_mut_ptr()) };
    if result == 0 {
        Some(unsafe { usage.assume_init().ru_maxrss as u64 } * 1024)
    } else {
        None
    }
}

#[cfg(not(target_os = "linux"))]
fn peak_memory_bytes() -> Option<u64> {
    None
}

struct BaselineRun {
    mode: &'static str,
    tree_depth: usize,
    tree_build_ms: u128,
    trace_build_ms: u128,
    proving_ms: u128,
    proof_size_bytes: usize,
    root: [BaseElement; 2],
    proof: Proof,
}

struct SecurityLevel {
    conjectured_bits: u32,
    proven_ldr_bits: u32,
    proven_udr_bits: u32,
}

struct VerificationMeasurement {
    warmup_iterations: usize,
    timed_iterations: usize,
    total: Duration,
}

impl VerificationMeasurement {
    fn mean_ns(&self) -> f64 {
        self.total.as_nanos() as f64 / self.timed_iterations as f64
    }
}

#[derive(Deserialize)]
struct WitnessNode {
    limb0: String,
    limb1: String,
}

#[derive(Deserialize)]
struct ExternalWitness {
    value_limb0: String,
    value_limb1: String,
    index: usize,
    path: Vec<WitnessNode>,
}

enum InputMode {
    Fallback { depth: usize },
    Witness { path: String, mode: ProverMode },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ProverMode {
    Baseline,
    SplitOptimized,
    Folded,
}

impl ProverMode {
    fn parse(value: &str) -> Self {
        match value {
            "baseline" => Self::Baseline,
            "split" => Self::SplitOptimized,
            "folded" => Self::Folded,
            _ => panic!("--mode must be baseline, split, or folded"),
        }
    }

    fn label(self) -> &'static str {
        match self {
            Self::Baseline => "baseline",
            Self::SplitOptimized => "split-optimized",
            Self::Folded => "folded",
        }
    }
}

fn proof_options(mode: ProverMode) -> ProofOptions {
    let fri_folding_factor = match mode {
        ProverMode::Folded => 16,
        ProverMode::Baseline | ProverMode::SplitOptimized => 8,
    };

    ProofOptions::new(
        28,
        8,
        0,
        FieldExtension::None,
        fri_folding_factor,
        31,
        BatchingMethod::Linear,
        BatchingMethod::Linear,
    )
}

// SplitMix64 is only a deterministic Phase 3 fixture generator. It is replaced
// by issuer-provided credential/tree data in Phase 4.
fn next_u64(state: &mut u64) -> u64 {
    *state = state.wrapping_add(0x9E3779B97F4A7C15);
    let mut value = *state;
    value = (value ^ (value >> 30)).wrapping_mul(0xBF58476D1CE4E5B9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94D049BB133111EB);
    value ^ (value >> 31)
}

fn seeded_base_elements(seed: u64, count: usize) -> Vec<BaseElement> {
    let mut state = seed;
    (0..count)
        .map(|_| BaseElement::new(next_u64(&mut state) as u128))
        .collect()
}

fn seeded_index(seed: u64, leaf_count: usize) -> usize {
    let mut state = seed.wrapping_add(1);
    (next_u64(&mut state) as usize) % leaf_count
}

fn build_merkle_tree(
    depth: usize,
    value: [BaseElement; 2],
    index: usize,
    seed: u64,
) -> MerkleTree<Rescue128> {
    let leaf_count = 1usize << depth;
    let elements = seeded_base_elements(seed, leaf_count * 2);
    let mut leaves: Vec<Hash> = elements
        .chunks_exact(2)
        .map(|pair| Hash::new(pair[0], pair[1]))
        .collect();

    leaves[index] = Rescue128::digest(&value);
    MerkleTree::new(leaves).expect("generated leaves form a valid Merkle tree")
}

fn create_baseline_run(tree_depth: usize, tree_seed: u64, mode: ProverMode) -> BaselineRun {
    assert!(
        tree_depth > 0 && (tree_depth + 1).is_power_of_two(),
        "tree depth must be one less than a power of two (for example 3, 7, or 15)"
    );

    let value = [BaseElement::new(42), BaseElement::new(43)];
    let leaf_count = 1usize << tree_depth;
    let index = seeded_index(tree_seed, leaf_count);

    let tree_started = Instant::now();
    let tree = build_merkle_tree(tree_depth, value, index, tree_seed);
    let tree_build_ms = tree_started.elapsed().as_millis();

    let (leaf, authentication_path) = tree.prove(index).expect("index belongs to the tree");
    let mut branch = vec![leaf];
    branch.extend_from_slice(&authentication_path);

    let prover = MerkleProver::<StarkCommitmentHasher>::new(proof_options(mode));
    let trace_started = Instant::now();
    let trace = prover.build_trace(value, &branch, index);
    let trace_build_ms = trace_started.elapsed().as_millis();

    let proving_started = Instant::now();
    let proof = prover
        .prove(trace)
        .expect("baseline proof generation must succeed");
    let proving_ms = proving_started.elapsed().as_millis();

    BaselineRun {
        mode: mode.label(),
        tree_depth,
        tree_build_ms,
        trace_build_ms,
        proving_ms,
        proof_size_bytes: proof.to_bytes().len(),
        root: tree.root().to_elements(),
        proof,
    }
}

fn load_witness(path: &Path) -> ExternalWitness {
    let file = File::open(path).expect("failed to read witness file");
    serde_json::from_reader(BufReader::new(file))
        .expect("witness file must match the issuer witness JSON schema")
}

fn parse_witness_element(value: String, field_name: &str) -> BaseElement {
    BaseElement::new(
        value
            .parse()
            .unwrap_or_else(|_| panic!("invalid witness {field_name}")),
    )
}

fn into_witness_parts(witness: ExternalWitness) -> ([BaseElement; 2], usize, Vec<Hash>) {
    let ExternalWitness {
        value_limb0,
        value_limb1,
        index,
        path,
    } = witness;
    let value = [
        parse_witness_element(value_limb0, "value_limb0"),
        parse_witness_element(value_limb1, "value_limb1"),
    ];
    let path = path
        .into_iter()
        .map(|node| {
            Hash::new(
                parse_witness_element(node.limb0, "path limb0"),
                parse_witness_element(node.limb1, "path limb1"),
            )
        })
        .collect();
    (value, index, path)
}

fn create_witness_run(witness: ExternalWitness, mode: ProverMode) -> BaselineRun {
    let (value, index, path) = into_witness_parts(witness);
    assert!(!path.is_empty(), "witness path must not be empty");
    let tree_depth = path.len();
    let root = root_from_path(value, &path, index).to_elements();
    let prover = MerkleProver::<StarkCommitmentHasher>::new(proof_options(mode));
    let trace_started = Instant::now();
    let trace = match mode {
        ProverMode::Baseline => {
            let mut branch = Vec::with_capacity(path.len() + 1);
            branch.push(Rescue128::digest(&value));
            branch.extend_from_slice(&path);
            prover.build_trace(value, &branch, index)
        }
        ProverMode::SplitOptimized => prover.build_trace_from_path(value, &path, index),
        ProverMode::Folded => prover.build_trace_from_path(value, &path, index),
    };
    drop(path);
    let trace_build_ms = trace_started.elapsed().as_millis();
    let proving_started = Instant::now();
    let proof = prover
        .prove(trace)
        .expect("witness proof generation must succeed");

    BaselineRun {
        mode: mode.label(),
        tree_depth,
        tree_build_ms: 0,
        trace_build_ms,
        proving_ms: proving_started.elapsed().as_millis(),
        proof_size_bytes: proof.to_bytes().len(),
        root,
        proof,
    }
}

fn proof_security(proof: &Proof) -> SecurityLevel {
    let proven = proof.proven_security::<StarkCommitmentHasher>();
    SecurityLevel {
        conjectured_bits: proof.conjectured_security::<StarkCommitmentHasher>().bits(),
        proven_ldr_bits: proven.ldr_bits(),
        proven_udr_bits: proven.udr_bits(),
    }
}

fn verify_proof(proof: Proof, root: [BaseElement; 2]) -> Result<(), VerifierError> {
    let acceptable_options =
        winterfell::AcceptableOptions::OptionSet(vec![proof.options().clone()]);
    winterfell::verify::<
        MerkleAir,
        StarkCommitmentHasher,
        DefaultRandomCoin<StarkCommitmentHasher>,
        MerkleTree<StarkCommitmentHasher>,
    >(proof, PublicInputs { tree_root: root }, &acceptable_options)
}

fn verification_iterations(variable: &str, default: usize) -> usize {
    std::env::var(variable)
        .ok()
        .map(|value| {
            value
                .parse()
                .expect("verification iteration count must be a positive integer")
        })
        .filter(|count: &usize| *count > 0)
        .unwrap_or(default)
}

fn measure_verification(
    proof: &Proof,
    root: [BaseElement; 2],
    warmup_iterations: usize,
    timed_iterations: usize,
) -> Result<VerificationMeasurement, VerifierError> {
    for _ in 0..warmup_iterations {
        verify_proof(proof.clone(), root)?;
    }

    let started = Instant::now();
    for _ in 0..timed_iterations {
        verify_proof(proof.clone(), root)?;
    }

    Ok(VerificationMeasurement {
        warmup_iterations,
        timed_iterations,
        total: started.elapsed(),
    })
}

fn parse_root_override(values: &[String]) -> Option<[BaseElement; 2]> {
    match (values.first(), values.get(1)) {
        (Some(limb0), Some(limb1)) => Some([
            BaseElement::new(limb0.parse().expect("root limb 0 must be a decimal u128")),
            BaseElement::new(limb1.parse().expect("root limb 1 must be a decimal u128")),
        ]),
        (None, None) => None,
        _ => panic!("supply both Ethereum root limbs or neither"),
    }
}

fn parse_input(args: &[String]) -> (InputMode, Option<[BaseElement; 2]>) {
    match args.get(1).map(String::as_str) {
        Some("--witness") => {
            let path = args
                .get(2)
                .expect("--witness requires a witness file path")
                .clone();
            let (mode, root_values) = match args.get(3).map(String::as_str) {
                Some("--mode") => (
                    ProverMode::parse(
                        args.get(4)
                            .expect("--mode requires baseline, split, or folded"),
                    ),
                    &args[5..],
                ),
                _ => (ProverMode::Baseline, &args[3..]),
            };
            let root = parse_root_override(root_values);
            assert!(
                root.is_some(),
                "witness mode requires the public Ethereum root limbs"
            );
            (InputMode::Witness { path, mode }, root)
        }
        _ => {
            let depth = args
                .get(1)
                .map(|value| {
                    value
                        .parse()
                        .expect("tree depth must be a positive integer")
                })
                .unwrap_or(DEFAULT_TREE_DEPTH);
            (
                InputMode::Fallback { depth },
                parse_root_override(&args[2..]),
            )
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let (input_mode, ethereum_root) = parse_input(&args);
    let tree_seed = std::env::var("TREE_SEED")
        .ok()
        .map(|value| {
            value
                .parse()
                .expect("TREE_SEED must be an unsigned integer")
        })
        .unwrap_or(DEFAULT_TREE_SEED);
    let run = match input_mode {
        InputMode::Fallback { depth } => {
            create_baseline_run(depth, tree_seed, ProverMode::Baseline)
        }
        InputMode::Witness { path, mode } => {
            create_witness_run(load_witness(Path::new(&path)), mode)
        }
    };
    let used_root = ethereum_root.unwrap_or(run.root);
    let root_source = if ethereum_root.is_some() {
        "ethereum"
    } else {
        "local"
    };

    let security = proof_security(&run.proof);
    let fri_options = run.proof.options().to_fri_options();
    let verification_warmup_iterations =
        verification_iterations("VERIFY_WARMUP_ITERATIONS", DEFAULT_VERIFY_WARMUP_ITERATIONS);
    let verification_timed_iterations =
        verification_iterations("VERIFY_TIMED_ITERATIONS", DEFAULT_VERIFY_TIMED_ITERATIONS);
    let verification_result = measure_verification(
        &run.proof,
        used_root,
        verification_warmup_iterations,
        verification_timed_iterations,
    );
    let verified = verification_result.is_ok();
    let verification_total_ns = verification_result
        .as_ref()
        .map(|measurement| measurement.total.as_nanos().to_string())
        .unwrap_or_else(|_| "null".to_owned());
    let verification_mean_ns = verification_result
        .as_ref()
        .map(|measurement| format!("{:.3}", measurement.mean_ns()))
        .unwrap_or_else(|_| "null".to_owned());
    let verification_ms = verification_result
        .as_ref()
        .map(|measurement| format!("{:.6}", measurement.mean_ns() / 1_000_000.0))
        .unwrap_or_else(|_| "null".to_owned());
    let reported_warmup_iterations = verification_result
        .as_ref()
        .map(|measurement| measurement.warmup_iterations)
        .unwrap_or(verification_warmup_iterations);
    let reported_timed_iterations = verification_result
        .as_ref()
        .map(|measurement| measurement.timed_iterations)
        .unwrap_or(verification_timed_iterations);
    let peak_memory = peak_memory_bytes()
        .map(|bytes| bytes.to_string())
        .unwrap_or_else(|| "null".to_owned());

    println!(
        concat!(
            "{{\"mode\":\"{}\",\"tree_depth\":{},\"num_leaves\":{},\"tree_build_ms\":{},",
            "\"trace_build_ms\":{},\"proving_ms\":{},\"peak_memory_bytes\":{},\"proof_size_bytes\":{},",
            "\"verification_ms\":{},\"verification_total_ns\":{},\"verification_mean_ns\":{},",
            "\"verification_warmup_iterations\":{},\"verification_timed_iterations\":{},",
            "\"fri_folding_factor\":{},\"fri_remainder_max_degree\":{},",
            "\"conjectured_security_bits\":{},\"proven_security_ldr_bits\":{},\"proven_security_udr_bits\":{},",
            "\"verified\":{},\"root_limb0\":\"{}\",",
            "\"root_limb1\":\"{}\",\"root_source\":\"{}\"}}"
        ),
        run.mode,
        run.tree_depth,
        1usize << run.tree_depth,
        run.tree_build_ms,
        run.trace_build_ms,
        run.proving_ms,
        peak_memory,
        run.proof_size_bytes,
        verification_ms,
        verification_total_ns,
        verification_mean_ns,
        reported_warmup_iterations,
        reported_timed_iterations,
        fri_options.folding_factor(),
        fri_options.remainder_max_degree(),
        security.conjectured_bits,
        security.proven_ldr_bits,
        security.proven_udr_bits,
        verified,
        run.root[0].as_int(),
        run.root[1].as_int(),
        root_source,
    );

    verification_result.expect("proof must verify against the selected Merkle root");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn baseline_roundtrip_verifies() {
        let run = create_baseline_run(3, DEFAULT_TREE_SEED, ProverMode::Baseline);
        assert!(verify_proof(run.proof, run.root).is_ok());
    }

    #[test]
    fn tampered_root_fails_verification() {
        let run = create_baseline_run(3, DEFAULT_TREE_SEED, ProverMode::Baseline);
        let wrong_root = [run.root[1], run.root[0]];
        assert!(verify_proof(run.proof, wrong_root).is_err());
    }

    #[test]
    fn same_seed_reconstructs_the_same_root() {
        let first = create_baseline_run(3, DEFAULT_TREE_SEED, ProverMode::Baseline);
        let second = create_baseline_run(3, DEFAULT_TREE_SEED, ProverMode::Baseline);
        assert_eq!(first.root, second.root);
    }

    #[test]
    fn folded_roundtrip_verifies_with_unchanged_security_parameters() {
        let baseline = proof_options(ProverMode::Baseline);
        let folded = proof_options(ProverMode::Folded);
        assert_eq!(baseline.num_queries(), folded.num_queries());
        assert_eq!(baseline.blowup_factor(), folded.blowup_factor());
        assert_eq!(baseline.grinding_factor(), folded.grinding_factor());
        assert_eq!(baseline.field_extension(), folded.field_extension());
        assert_eq!(
            baseline.constraint_batching_method(),
            folded.constraint_batching_method()
        );
        assert_eq!(
            baseline.deep_poly_batching_method(),
            folded.deep_poly_batching_method()
        );
        assert_eq!(
            baseline.to_fri_options().remainder_max_degree(),
            folded.to_fri_options().remainder_max_degree()
        );
        assert_eq!(baseline.to_fri_options().folding_factor(), 8);
        assert_eq!(folded.to_fri_options().folding_factor(), 16);

        let run = create_baseline_run(3, DEFAULT_TREE_SEED, ProverMode::Folded);
        assert!(verify_proof(run.proof, run.root).is_ok());
    }

    #[test]
    fn verification_batch_executes_requested_validations() {
        let run = create_baseline_run(3, DEFAULT_TREE_SEED, ProverMode::Folded);
        let measurement = measure_verification(&run.proof, run.root, 2, 3).unwrap();
        assert_eq!(measurement.warmup_iterations, 2);
        assert_eq!(measurement.timed_iterations, 3);
        assert!(measurement.total > Duration::ZERO);
        assert!(measurement.mean_ns() > 0.0);
    }
}
